<?php 
	include '../Classes/users.php';

	$nom =  $_POST['txt_nom'];
	$prenom =  $_POST['txt_prenom'];
	$mail = $_POST["txt_mail"];
	$id = $_POST["txt_id"];
	
	//$user = new users();
	users::inserer($mail,$nom,$prenom,$id);
	
 ?>