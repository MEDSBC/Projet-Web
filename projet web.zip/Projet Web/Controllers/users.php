
<?php 
      include 'classes/users.php';
          $users= users::get_users();
          foreach($users as $user) {                                                   
?>
         <tr>
             <td><?php echo $user[0]; ?></td>
             <td><?php echo $user[1]; ?></td>
             <td><?php echo $user[2]; ?></td>
          </tr>

<?php 
    } 
?>
